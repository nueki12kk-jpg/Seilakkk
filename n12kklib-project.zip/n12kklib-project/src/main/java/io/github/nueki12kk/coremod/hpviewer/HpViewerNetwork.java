package io.github.nueki12kk.coremod.hpviewer;

import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import cpw.mods.fml.relauncher.Side;
import io.github.nueki12kk.coremod.hpviewer.client.packet.PacketRequestPlayerNBT;
import io.github.nueki12kk.coremod.hpviewer.client.packet.PacketSendPlayerNBT;

public class HpViewerNetwork {

    public static final SimpleNetworkWrapper CHANNEL = NetworkRegistry.INSTANCE.newSimpleChannel("hpviewermod");

    public static void registerMessages() {
        int id = 0;
        CHANNEL.registerMessage(PacketSendPlayerNBT.Handler.class, PacketSendPlayerNBT.class, id++, Side.CLIENT);
        CHANNEL.registerMessage(PacketRequestPlayerNBT.Handler.class, PacketRequestPlayerNBT.class, id++, Side.SERVER);
    }
}
