package io.github.nueki12kk.coremod;

import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.common.MinecraftForge;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.eventhandler.EventPriority;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import io.github.nueki12kk.coremod.client.gui.menu.CustomGuiIngameMenu;
import io.github.nueki12kk.coremod.hpviewer.HpViewerNetwork;
import io.github.nueki12kk.coremod.hpviewer.ServerAllowlistGuard;
import io.github.nueki12kk.coremod.hpviewer.client.listeners.RenderHealthBarListener;

@Mod(modid = "n12kklib", version = "1.0", dependencies = "required-before:jinryuujrmcore")
public class Main {

    public static final String MODID = "n12kklib";
    public static final String VERSION = "1.0";

    @Mod.EventHandler
    public void init(FMLPreInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register((Object) this);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        HpViewerNetwork.registerMessages();
        if (event.getSide() == Side.CLIENT) {
            FMLCommonHandler.instance()
                .bus()
                .register((Object) new ServerAllowlistGuard());
            MinecraftForge.EVENT_BUS.register(new RenderHealthBarListener());
        }
    }

    @SideOnly(value = Side.CLIENT)
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void openGui(GuiOpenEvent event) {
        if (event.gui instanceof GuiIngameMenu) {
            event.gui = new CustomGuiIngameMenu();
        }
    }
}
