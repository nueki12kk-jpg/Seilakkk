package io.github.nueki12kk.coremod.hpviewer.client.packet;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;

import cpw.mods.fml.common.network.ByteBufUtils;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import io.netty.buffer.ByteBuf;

public class PacketRequestPlayerNBT implements IMessage {

    private String uuid;

    public PacketRequestPlayerNBT() {}

    public PacketRequestPlayerNBT(String uuid) {
        this.uuid = uuid;
    }

    public String getUUID() {
        return this.uuid;
    }

    public void toBytes(ByteBuf buf) {
        ByteBufUtils.writeUTF8String(buf, this.uuid);
    }

    public void fromBytes(ByteBuf buf) {
        this.uuid = ByteBufUtils.readUTF8String(buf);
    }

    public static class Handler implements IMessageHandler<PacketRequestPlayerNBT, IMessage> {

        private static boolean matches(PacketRequestPlayerNBT request, EntityPlayerMP player) {
            return player.getUniqueID()
                .toString()
                .equals(request.getUUID());
        }

        public IMessage onMessage(PacketRequestPlayerNBT request, MessageContext ctx) {
            EntityPlayerMP target = ctx.getServerHandler().playerEntity.mcServer
                .getConfigurationManager().playerEntityList.stream()
                    .filter(player -> matches(request, player))
                    .findFirst()
                    .orElse(null);
            if (target != null) {
                NBTTagCompound nbt = new NBTTagCompound();
                target.writeToNBT(nbt);
                return new PacketSendPlayerNBT(request.getUUID(), nbt);
            }
            return null;
        }
    }
}
