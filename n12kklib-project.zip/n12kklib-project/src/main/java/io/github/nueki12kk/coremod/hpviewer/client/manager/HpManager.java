package io.github.nueki12kk.coremod.hpviewer.client.manager;

import java.util.HashMap;
import java.util.Map;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;

public class HpManager {

    public static NBTTagCompound nbtPlayer = new NBTTagCompound();
    public static final Map<String, NBTTagCompound> playersNBT = new HashMap<String, NBTTagCompound>();
    public static final ResourceLocation barPreta = new ResourceLocation("hpviewer", "textures/bar2.png");
    public static final ResourceLocation barVerde = new ResourceLocation("hpviewer", "textures/bar1.png");
    public static final ResourceLocation barAzul = new ResourceLocation("hpviewer", "textures/barAzul.png");
}
