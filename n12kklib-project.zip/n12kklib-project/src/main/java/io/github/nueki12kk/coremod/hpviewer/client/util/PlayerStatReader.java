package io.github.nueki12kk.coremod.hpviewer.client.util;

import java.math.BigInteger;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.nbt.NBTTagCompound;

import JinRyuu.JRMCore.JRMCoreH;

public class PlayerStatReader {

    private static final String ROOT_TAG = "PlayerPersisted";
    private static final String CURRENT_BODY_KEY = "n12kk:bodyCurrent";
    private static final String MAX_BODY_KEY = "n12kk:bodyMax";
    private static final String CURRENT_KI_KEY = "n12kk:kiCurrent";
    private static final String MAX_KI_KEY = "n12kk:kiMax";

    public EntityLivingBase entity;
    public NBTTagCompound data;

    public PlayerStatReader(EntityLivingBase entity) {
        this.entity = entity;
    }

    public PlayerStatReader(NBTTagCompound nbt, EntityLivingBase entity) {
        this.data = nbt.getCompoundTag("ForgeData");
        this.entity = entity;
    }

    private NBTTagCompound persisted() {
        return this.data.getCompoundTag(ROOT_TAG);
    }

    private static BigInteger readBigMirror(NBTTagCompound nbt, String stringKey, String intKey, String longKey) {
        if (nbt == null) {
            return BigInteger.ZERO;
        }
        if (nbt.hasKey(stringKey, 8)) {
            try {
                return new BigInteger(nbt.getString(stringKey), 10).max(BigInteger.ZERO);
            } catch (NumberFormatException ignored) {}
        }
        int intPool = Math.max(0, nbt.getInteger(intKey));
        long overflow = Math.max(0L, nbt.getLong(longKey));
        return BigInteger.valueOf(intPool)
            .add(BigInteger.valueOf(overflow));
    }

    private static BigInteger readStoredMax(NBTTagCompound nbt, String maxKey) {
        if (nbt == null || !nbt.hasKey(maxKey, 8)) {
            return null;
        }
        try {
            BigInteger value = new BigInteger(nbt.getString(maxKey));
            return value.signum() < 0 ? BigInteger.ZERO : value;
        } catch (Throwable ignored) {
            return null;
        }
    }

    public BigInteger getCurBodyBig() {
        return readBigMirror(this.persisted(), CURRENT_BODY_KEY, "jrmcBdy", "n12kk_jrmcBdy");
    }

    public BigInteger getMaxBodyBig() {
        BigInteger stored = readStoredMax(this.persisted(), MAX_BODY_KEY);
        if (stored != null && stored.signum() > 0) {
            return stored;
        }
        return BigInteger.valueOf(
            Math.max(
                0,
                this.computeMaxHp()
                    .intValue()));
    }

    public BigInteger getCurKiBig() {
        return readBigMirror(this.persisted(), CURRENT_KI_KEY, "jrmcEnrgy", "n12kk_jrmcEnrgy");
    }

    public BigInteger getMaxKiBig() {
        BigInteger stored = readStoredMax(this.persisted(), MAX_KI_KEY);
        if (stored != null && stored.signum() > 0) {
            return stored;
        }
        return BigInteger.valueOf(Math.max(0, this.computeMaxEnergy()));
    }

    public Byte getJrmcRace() {
        return Byte.valueOf(
            this.data.getCompoundTag(ROOT_TAG)
                .getByte("jrmcRace"));
    }

    public Integer getJrmcCnsI() {
        return Integer.valueOf(
            this.data.getCompoundTag(ROOT_TAG)
                .getInteger("jrmcCnsI"));
    }

    public Integer getJrmcBdy() {
        return Integer.valueOf(
            this.data.getCompoundTag(ROOT_TAG)
                .getInteger("jrmcBdy"));
    }

    public Integer getJrmcEnrgyAlt() {
        return Integer.valueOf(
            this.data.getCompoundTag(ROOT_TAG)
                .getInteger("jrmcEnrgy"));
    }

    public Byte getJrmcPwrtyp() {
        return Byte.valueOf(
            this.data.getCompoundTag(ROOT_TAG)
                .getByte("jrmcPwrtyp"));
    }

    public String getJrmcSSlts() {
        return this.data.getCompoundTag(ROOT_TAG)
            .getString("jrmcSSlts");
    }

    public Integer getJrmcRelease() {
        return Integer.valueOf(
            this.data.getCompoundTag(ROOT_TAG)
                .getInteger("jrmcRelease"));
    }

    public Integer getJrmcEnrgy() {
        return Integer.valueOf(
            this.data.getCompoundTag(ROOT_TAG)
                .getInteger("jrmcEnrgy"));
    }

    public Byte getJrmcClass() {
        return Byte.valueOf(
            this.data.getCompoundTag(ROOT_TAG)
                .getByte("jrmcClass"));
    }

    public Integer getJrmcCncI() {
        return Integer.valueOf(
            this.data.getCompoundTag(ROOT_TAG)
                .getInteger("jrmcCncI"));
    }

    public Integer computeMaxHp() {
        int result = JRMCoreH.stat(
            (Entity) this.entity,
            2,
            this.getJrmcPwrtyp()
                .byteValue(),
            2,
            this.getJrmcCnsI()
                .intValue(),
            this.getJrmcRace()
                .byteValue(),
            this.getJrmcClass()
                .byteValue(),
            0.0f);
        return Integer.valueOf(result);
    }

    public int computeMaxEnergy() {
        float sklLvl = JRMCoreH.SklLvl_KiBs(
            this.getJrmcSSlts()
                .split(","),
            1);
        return JRMCoreH.stat(
            (Entity) this.entity,
            5,
            this.getJrmcPwrtyp()
                .byteValue(),
            5,
            this.getJrmcCncI()
                .intValue(),
            this.getJrmcRace()
                .byteValue(),
            this.getJrmcClass()
                .byteValue(),
            sklLvl);
    }
}
