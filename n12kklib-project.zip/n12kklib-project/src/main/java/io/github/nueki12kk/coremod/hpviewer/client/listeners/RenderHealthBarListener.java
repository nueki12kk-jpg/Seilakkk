package io.github.nueki12kk.coremod.hpviewer.client.listeners;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.client.event.RenderLivingEvent;

import org.lwjgl.opengl.GL11;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import io.github.nueki12kk.coremod.hpviewer.HpViewerNetwork;
import io.github.nueki12kk.coremod.hpviewer.client.manager.HpManager;
import io.github.nueki12kk.coremod.hpviewer.client.packet.PacketRequestPlayerNBT;
import io.github.nueki12kk.coremod.hpviewer.client.render.BarRenderer;
import io.github.nueki12kk.coremod.hpviewer.client.render.FloatingTextBuilder;
import io.github.nueki12kk.coremod.hpviewer.client.util.NumberFormatter;
import io.github.nueki12kk.coremod.hpviewer.client.util.PlayerStatReader;

public class RenderHealthBarListener {

    private static final Map<String, Long> lastRequestTime = new HashMap<String, Long>();
    private static final long REQUEST_DELAY_MS = 1000L;

    public static void restoreGLState() {
        GL11.glPopMatrix();
    }

    public static void prepareGLTransformations(double x, double y, double z) {
        RenderManager renderManager = RenderManager.instance;
        GL11.glPushMatrix();
        GL11.glTranslated(x, y, z);
        GL11.glRotatef(-renderManager.playerViewY, 0.0f, 1.0f, 0.0f);
    }

    private void renderHp(NBTTagCompound nbt, EntityPlayer player, RenderLivingEvent.Post event,
        PlayerStatReader stats) {
        BigInteger currentHp = stats.getCurBodyBig();
        BigInteger maxHp = stats.getMaxBodyBig();
        BigInteger currentKi = stats.getCurKiBig();

        prepareGLTransformations(event.x, event.y + 2.200000047683716d, event.z);
        GL11.glScalef(0.02f, 0.02f, 0.02f);
        GL11.glPushAttrib(GL11.GL_ENABLE_BIT | GL11.GL_COLOR_BUFFER_BIT);
        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDisable(GL11.GL_ALPHA_TEST);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

        int barWidth = 106;
        Minecraft.getMinecraft()
            .getTextureManager()
            .bindTexture(HpManager.barPreta);
        BarRenderer.drawTexturedRect(-barWidth / 2, 10.0f, 0.0f, 0.0f, 106, 8, 106.0f, 8.0f);

        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(false);
        Minecraft.getMinecraft()
            .getTextureManager()
            .bindTexture(HpManager.barVerde);
        int filledWidth = percentBarWidthBig(currentHp, maxHp, 106.0f);
        BarRenderer.drawTexturedRect(-barWidth / 2, 10.5f, 0.0f, 0.0f, filledWidth, 7, 106.0f, 7.0f);

        GL11.glDepthMask(true);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glPopAttrib();
        restoreGLState();

        float px = (float) event.x;
        float py = (float) event.y + 2.7f;
        float pz = (float) event.z;

        new FloatingTextBuilder("\u2764 " + NumberFormatter.formatShort(currentHp)).scale(0.7f)
            .color(-1359820)
            .outlineEnabled(true)
            .outlineColor(15)
            .outlineRadius(0.005)
            .render(px, py, pz);

        new FloatingTextBuilder("\u00a77:").scale(0.8f)
            .render(px, py, pz);

        new FloatingTextBuilder("\u26a1 " + NumberFormatter.formatShort(currentKi)).scale(0.7f)
            .color(58364)
            .outlineEnabled(true)
            .outlineColor(15)
            .outlineRadius(1.0)
            .render(px, py, pz);
    }

    private void renderNpc(EntityLivingBase entity, RenderLivingEvent.Post event) {
        if (entity == null || entity.isDead) {
            return;
        }
        float currentHp = entity.getHealth();
        float maxHp = entity.getMaxHealth();

        prepareGLTransformations(event.x, event.y + 2.200000047683716d, event.z);
        GL11.glScalef(0.02f, 0.02f, 0.02f);
        GL11.glPushAttrib(GL11.GL_ENABLE_BIT | GL11.GL_COLOR_BUFFER_BIT);
        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDisable(GL11.GL_ALPHA_TEST);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

        int barWidth = 106;
        Minecraft.getMinecraft()
            .getTextureManager()
            .bindTexture(HpManager.barPreta);
        BarRenderer.drawTexturedRect(-barWidth / 2, 10.0f, 0.0f, 0.0f, 106, 8, 106.0f, 8.0f);

        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(false);
        Minecraft.getMinecraft()
            .getTextureManager()
            .bindTexture(HpManager.barVerde);
        int filledWidth = percentBarWidth(currentHp, maxHp, 106.0f);
        BarRenderer.drawTexturedRect(-barWidth / 2, 10.5f, 0.0f, 0.0f, filledWidth, 7, 106.0f, 7.0f);

        GL11.glDepthMask(true);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glPopAttrib();
        restoreGLState();

        new FloatingTextBuilder("\u2764 " + NumberFormatter.formatShort(currentHp)).scale(0.7f)
            .color(-1359820)
            .outlineEnabled(true)
            .outlineColor(15)
            .outlineRadius(0.005)
            .render((float) event.x, (float) event.y + 2.7f, (float) event.z);
    }

    private void renderEnergy(NBTTagCompound nbt, EntityPlayer player, RenderLivingEvent.Post event,
        PlayerStatReader stats) {
        prepareGLTransformations(event.x, event.y + 2.200000047683716d, event.z);
        GL11.glScalef(0.022f, 0.02f, 0.019f);
        GL11.glPushAttrib(GL11.GL_ENABLE_BIT | GL11.GL_COLOR_BUFFER_BIT);
        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDisable(GL11.GL_ALPHA_TEST);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

        BigInteger maxEnergy = stats.getMaxKiBig();
        BigInteger currentEnergy = stats.getCurKiBig();
        int barWidth = 69;

        Minecraft.getMinecraft()
            .getTextureManager()
            .bindTexture(HpManager.barAzul);
        int filledWidth = percentBarWidthBig(currentEnergy, maxEnergy, barWidth);
        BarRenderer.drawTexturedRect(-35.0f, 7.0f, 0.0f, 0.0f, filledWidth, 2, 69.0f, 2.0f);

        GL11.glPopAttrib();
        restoreGLState();
    }

    private static int percentBarWidth(float current, float max, float barWidth) {
        float clamped = Math.max(0.0f, Math.min(current, max));
        return (int) ((clamped / max) * barWidth);
    }

    private static int percentBarWidthBig(BigInteger current, BigInteger max, float barWidth) {
        if (max == null || max.signum() <= 0) {
            return 0;
        }
        BigInteger clamped = current == null ? BigInteger.ZERO : current;
        if (clamped.signum() < 0) {
            clamped = BigInteger.ZERO;
        }
        if (clamped.compareTo(max) > 0) {
            clamped = max;
        }
        BigInteger scaled = clamped.multiply(BigInteger.valueOf(10000L))
            .divide(max);
        float ratio = scaled.intValue() / 10000.0f;
        return (int) (ratio * barWidth);
    }

    @SubscribeEvent
    public void onRenderLiving(RenderLivingEvent.Post event) {
        EntityLivingBase entity = event.entity;
        Minecraft mc = Minecraft.getMinecraft();
        if (entity == mc.thePlayer) {
            return;
        }
        if (entity.isDead || entity.getHealth() <= 0.0f) {
            return;
        }
        double maxDistSq = 25.0d * 25.0d;
        if (mc.thePlayer.getDistanceSq(entity.posX, entity.posY, entity.posZ) > maxDistSq) {
            return;
        }
        if (entity instanceof EntityPlayer) {
            renderPlayer((EntityPlayer) entity, event);
        } else {
            renderNpc(entity, event);
        }
    }

    private void renderPlayer(EntityPlayer player, RenderLivingEvent.Post event) {
        String uuid = player.getUniqueID()
            .toString();
        long now = System.currentTimeMillis();
        Long lastTime = lastRequestTime.get(uuid);
        if (lastTime == null || now - lastTime.longValue() >= REQUEST_DELAY_MS) {
            HpViewerNetwork.CHANNEL.sendToServer(new PacketRequestPlayerNBT(uuid));
            lastRequestTime.put(uuid, Long.valueOf(now));
        }
        NBTTagCompound nbt = HpManager.playersNBT.get(uuid);
        if (nbt != null) {
            PlayerStatReader stats = new PlayerStatReader(nbt, player);
            renderHp(nbt, player, event, stats);
            renderEnergy(nbt, player, event, stats);
        }
    }

    public RenderHealthBarListener() {}
}
