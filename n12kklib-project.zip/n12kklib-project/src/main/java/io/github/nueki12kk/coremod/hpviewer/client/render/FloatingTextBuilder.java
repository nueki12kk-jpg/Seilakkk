package io.github.nueki12kk.coremod.hpviewer.client.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.entity.RenderManager;

import org.lwjgl.opengl.GL11;

public class FloatingTextBuilder {

    private String text;
    private int color = 0xFFFFFFFF;
    private float scale = 1.0f;
    private int outlineColor = 0xFF000000;
    private final Minecraft mc;
    private double offsetX = 0.0;
    private double offsetZ = 0.0;
    private boolean outlineEnabled = true;
    private double offsetY = 0.0;
    private double outlineRadius = 1.0;

    public FloatingTextBuilder(String text) {
        this.mc = Minecraft.getMinecraft();
        this.text = text;
    }

    public FloatingTextBuilder scale(float scale) {
        this.scale = scale;
        return this;
    }

    public FloatingTextBuilder color(int color) {
        this.color = color;
        return this;
    }

    public FloatingTextBuilder alpha(int percent) {
        int clamped = Math.min(100, Math.max(0, percent));
        int alphaByte = (int) (((float) clamped / 100.0f) * 255.0f);
        this.color = (this.color & 0x00FFFFFF) | (alphaByte << 24);
        return this;
    }

    public FloatingTextBuilder outlineColor(int color) {
        this.outlineColor = color;
        return this;
    }

    public FloatingTextBuilder outlineEnabled(boolean enabled) {
        this.outlineEnabled = enabled;
        return this;
    }

    public FloatingTextBuilder outlineRadius(double radius) {
        this.outlineRadius = radius;
        return this;
    }

    public FloatingTextBuilder offsetX(double offsetX) {
        this.offsetX = offsetX;
        return this;
    }

    public FloatingTextBuilder offsetY(double offsetY) {
        this.offsetY = offsetY;
        return this;
    }

    public FloatingTextBuilder offsetZ(double offsetZ) {
        this.offsetZ = offsetZ;
        return this;
    }

    public void render2D(float x, float y) {
        FontRenderer fontRenderer = this.mc.fontRenderer;
        int halfWidth = fontRenderer.getStringWidth(this.text) / 2;
        fontRenderer.drawString(this.text, (int) x - halfWidth, (int) y, this.color, false);
    }

    public void render(double x, double y, double z) {
        FontRenderer fontRenderer = this.mc.fontRenderer;
        RenderManager renderManager = RenderManager.instance;
        float renderScale = this.scale * 0.016666668f;
        int halfWidth = fontRenderer.getStringWidth(this.text) / 2;

        GL11.glPushMatrix();
        GL11.glTranslated(x, y, z);
        GL11.glNormal3f(1.0f, 0.0f, 0.0f);
        GL11.glRotatef(-renderManager.playerViewY, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(renderManager.playerViewX, 1.0f, 0.0f, 0.0f);
        GL11.glTranslated(this.offsetX, this.offsetZ, this.offsetY);
        GL11.glScalef(-renderScale, -renderScale, renderScale);

        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDepthMask(false);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_TEXTURE_2D);

        if (this.outlineEnabled && this.outlineRadius > 0.0) {
            int radius = (int) Math.ceil(this.outlineRadius);
            for (int ox = -radius; ox <= radius; ox++) {
                for (int oy = -radius; oy <= radius; oy++) {
                    if (ox != 0 || oy != 0) {
                        fontRenderer.drawString(this.text, -halfWidth + ox, oy, this.outlineColor, true);
                    }
                }
            }
        }

        fontRenderer.drawString(this.text, -halfWidth, 1, this.color, false);

        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(true);
        GL11.glEnable(GL11.GL_LIGHTING);
        GL11.glPopMatrix();
    }
}
