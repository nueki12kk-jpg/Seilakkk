package io.github.nueki12kk.coremod.hpviewer.client.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class NumberFormatter {

    private static final DecimalFormat INTEGER_FORMAT = new DecimalFormat("#,###");
    private static final String[] SUFFIXES = { "", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc" };

    public static String format(Integer value) {
        return INTEGER_FORMAT.format(value);
    }

    public static String format(BigInteger value) {
        if (value == null) {
            return "0";
        }
        return INTEGER_FORMAT.format(value);
    }

    public static String formatShort(BigInteger value) {
        if (value == null) {
            return "0";
        }
        boolean negative = value.signum() < 0;
        BigInteger v = negative ? value.negate() : value;
        String digits = v.toString();
        if (digits.length() <= 3) {
            return (negative ? "-" : "") + digits;
        }
        int scale = (digits.length() - 1) / 3;
        if (scale >= SUFFIXES.length) {
            scale = SUFFIXES.length - 1;
        }
        BigDecimal divisor = BigDecimal.TEN.pow(scale * 3);
        BigDecimal scaled = new BigDecimal(v).divide(divisor, 1, RoundingMode.DOWN);
        return (negative ? "-" : "") + scaled.toPlainString() + SUFFIXES[scale];
    }

    public static String formatShort(float value) {
        if (value < 1000.0f) {
            return String.format("%.0f", value);
        }
        int scale = (int) (Math.log10(value) / 3.0);
        scale = Math.min(scale, SUFFIXES.length - 1);
        double divisor = Math.pow(1000.0, scale);
        long whole = (long) (value / divisor);
        long remainder = (long) (value % divisor);
        StringBuilder builder = new StringBuilder();
        builder.append(whole)
            .append(SUFFIXES[scale]);
        if (remainder >= 1L && scale > 0) {
            int remainderScale = scale - 1;
            remainder /= (long) Math.pow(1000.0, remainderScale);
            if (remainder > 0L) {
                builder.append(" e ")
                    .append(remainder)
                    .append(SUFFIXES[remainderScale]);
            }
        }
        return builder.toString();
    }

    public static String formatDecimal(float value) {
        if (value < 1000.0f) {
            return String.format("%.0f", value);
        }
        int scale = (int) (Math.log10(value) / 3.0);
        if (scale >= SUFFIXES.length) {
            scale = SUFFIXES.length - 1;
        }
        double scaled = value / Math.pow(1000.0, scale);
        return String.format("%.1f%s", scaled, SUFFIXES[scale]);
    }
}
