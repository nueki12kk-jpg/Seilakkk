package io.github.nueki12kk.coremod.hpviewer.client.packet;

import net.minecraft.nbt.NBTTagCompound;

import cpw.mods.fml.common.network.ByteBufUtils;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import io.github.nueki12kk.coremod.hpviewer.client.manager.HpManager;
import io.netty.buffer.ByteBuf;

public class PacketSendPlayerNBT implements IMessage {

    private NBTTagCompound data;
    private String uuid;

    public PacketSendPlayerNBT() {}

    public PacketSendPlayerNBT(String uuid, NBTTagCompound data) {
        this.uuid = uuid;
        this.data = data;
    }

    public void toBytes(ByteBuf buf) {
        ByteBufUtils.writeUTF8String(buf, this.uuid);
        ByteBufUtils.writeTag(buf, this.data != null ? this.data : new NBTTagCompound());
    }

    public void fromBytes(ByteBuf buf) {
        this.uuid = ByteBufUtils.readUTF8String(buf);
        this.data = ByteBufUtils.readTag(buf);
        if (this.data == null) {
            this.data = new NBTTagCompound();
        }
    }

    public static class Handler implements IMessageHandler<PacketSendPlayerNBT, IMessage> {

        public IMessage onMessage(PacketSendPlayerNBT message, MessageContext ctx) {
            HpManager.playersNBT.put(message.uuid, message.data);
            return null;
        }
    }
}
