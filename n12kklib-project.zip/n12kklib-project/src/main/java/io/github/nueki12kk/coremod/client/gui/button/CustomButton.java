package io.github.nueki12kk.coremod.client.gui.button;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.util.ResourceLocation;

import org.lwjgl.opengl.GL11;

public class CustomButton extends GuiButton {

    private final ResourceLocation texture;
    private final int uWidth;
    private final int vHeight;
    private final int uOffset;
    private final int vOffset;
    private final int hovervOffset;

    public CustomButton(int id, int x, int y, int width, int height, int uOffset, int vOffset, int hovervOffset,
        int uWidth, int vHeight, ResourceLocation texture) {
        super(id, x, y, width, height, "");
        this.uWidth = uWidth;
        this.vHeight = vHeight;
        this.uOffset = uOffset;
        this.vOffset = vOffset;
        this.hovervOffset = hovervOffset;
        this.texture = texture;
    }

    public void drawButton(Minecraft mc, int mouseX, int mouseY) {
        if (this.visible) {
            FontRenderer fontRenderer = mc.fontRenderer;
            mc.getTextureManager()
                .bindTexture(this.texture);
            GL11.glColor4f((float) 1.0f, (float) 1.0f, (float) 1.0f, (float) 1.0f);
            boolean isHovered = mouseX >= this.xPosition && mouseY >= this.yPosition
                && mouseX < this.xPosition + this.width
                && mouseY < this.yPosition + this.height;
            int k = this.getHoverState(isHovered);
            GL11.glEnable((int) 3042);
            GL11.glBlendFunc((int) 770, (int) 771);
            int currentVOffset = k == 2 ? this.vOffset + this.vHeight + this.hovervOffset : this.vOffset;
            this.blit(
                this.xPosition,
                this.yPosition,
                this.width,
                this.height,
                this.uOffset,
                currentVOffset,
                this.uWidth,
                this.vHeight,
                512,
                512);
            this.mouseDragged(mc, mouseX, mouseY);
        }
    }

    private void blit(int x, int y, int width, int height, float uOffset, float vOffset, int uWidth, int vHeight,
        int textureWidth, int textureHeight) {
        float minU = uOffset / (float) textureWidth;
        float maxU = (uOffset + (float) uWidth) / (float) textureWidth;
        float minV = vOffset / (float) textureHeight;
        float maxV = (vOffset + (float) vHeight) / (float) textureHeight;
        Tessellator tessellator = Tessellator.instance;
        tessellator.startDrawingQuads();
        tessellator
            .addVertexWithUV((double) x, (double) (y + height), (double) this.zLevel, (double) minU, (double) maxV);
        tessellator.addVertexWithUV(
            (double) (x + width),
            (double) (y + height),
            (double) this.zLevel,
            (double) maxU,
            (double) maxV);
        tessellator
            .addVertexWithUV((double) (x + width), (double) y, (double) this.zLevel, (double) maxU, (double) minV);
        tessellator.addVertexWithUV((double) x, (double) y, (double) this.zLevel, (double) minU, (double) minV);
        tessellator.draw();
    }
}
