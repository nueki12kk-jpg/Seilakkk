package io.github.nueki12kk.coremod.hpviewer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.network.FMLNetworkEvent;

public class ServerAllowlistGuard {

    private static final String[] ALLOWED_SERVERS = { "sp-02.magnohost.com.br:25539", "redeeclypse.srvmc.com" };

    @SubscribeEvent
    public void onConnected(FMLNetworkEvent.ClientConnectedToServerEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.isSingleplayer()) {
            return;
        }
        ServerData serverData = mc.func_147104_D();
        if (serverData == null) {
            mc.shutdown();
            return;
        }
        String address = serverData.serverIP.toLowerCase();
        for (String allowed : ALLOWED_SERVERS) {
            if (address.contains(allowed)) {
                return;
            }
        }
        mc.shutdown();
    }
}
