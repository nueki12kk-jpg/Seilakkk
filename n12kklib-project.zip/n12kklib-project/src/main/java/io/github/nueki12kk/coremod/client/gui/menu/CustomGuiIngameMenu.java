package io.github.nueki12kk.coremod.client.gui.menu;

import java.net.URI;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.util.ResourceLocation;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import io.github.nueki12kk.coremod.client.gui.button.CustomButton;

@SideOnly(value = Side.CLIENT)
public class CustomGuiIngameMenu extends GuiScreen {

    private static final Logger LOGGER = LogManager.getLogger();
    private static final ResourceLocation BACKGROUND = new ResourceLocation("eclypse:textures/gui/menu.png");
    private static final ResourceLocation BUTTONS1 = new ResourceLocation("eclypse:textures/gui/botoes.png");
    private static final ResourceLocation BUTTONS2 = new ResourceLocation("eclypse:textures/gui/botoes2.png");
    private static final String DISCORD_URL = "https://discord.gg/GgxyfZSUc9";
    private static final String WEBSITE_URL = "https://www.redeeclypse.srvmc.com";

    public void initGui() {
        this.buttonList.clear();
        int posX = this.width / 2 + 50;
        int posY = this.height / 2;
        this.buttonList.add(new CustomButton(0, posX - 50, posY - 60, 117, 25, 0, 0, 8, 342, 73, BUTTONS1));
        this.buttonList.add(new CustomButton(1, posX - 30, posY - 30, 120, 28, 0, 160, 1, 342, 91, BUTTONS1));
        this.buttonList.add(new CustomButton(2, posX - 10, posY, 127, 25, 0, 0, 5, 296, 58, BUTTONS2));
        this.buttonList.add(new CustomButton(3, posX + 20, posY + 30, 127, 25, 0, 137, 8, 296, 58, BUTTONS2));
        this.buttonList.add(new CustomButton(4, posX + 60, posY + 60, 66, 25, 0, 350, 7, 205, 77, BUTTONS1));
    }

    protected void actionPerformed(GuiButton button) {
        switch (button.id) {
            case 0: {
                this.mc.displayGuiScreen((GuiScreen) null);
                this.mc.setIngameFocus();
                break;
            }
            case 1: {
                this.mc.displayGuiScreen((GuiScreen) new GuiOptions((GuiScreen) this, this.mc.gameSettings));
                break;
            }
            case 2: {
                this.openUrl(WEBSITE_URL);
                break;
            }
            case 3: {
                this.openUrl(DISCORD_URL);
                break;
            }
            case 4: {
                this.mc.theWorld.sendQuittingDisconnectingPacket();
                this.mc.displayGuiScreen((GuiScreen) new GuiMainMenu());
            }
        }
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        this.mc.getTextureManager()
            .bindTexture(BACKGROUND);
        this.blit(0, 0, this.width, this.height, 0.0f, 0.0f, 1280, 720, 1280, 720);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private void blit(int x, int y, int width, int height, float uOffset, float vOffset, int uWidth, int vHeight,
        int textureWidth, int textureHeight) {
        float minU = uOffset / (float) textureWidth;
        float maxU = (uOffset + (float) uWidth) / (float) textureWidth;
        float minV = vOffset / (float) textureHeight;
        float maxV = (vOffset + (float) vHeight) / (float) textureHeight;
        Tessellator tessellator = Tessellator.instance;
        tessellator.startDrawingQuads();
        tessellator
            .addVertexWithUV((double) x, (double) (y + height), (double) this.zLevel, (double) minU, (double) maxV);
        tessellator.addVertexWithUV(
            (double) (x + width),
            (double) (y + height),
            (double) this.zLevel,
            (double) maxU,
            (double) maxV);
        tessellator
            .addVertexWithUV((double) (x + width), (double) y, (double) this.zLevel, (double) maxU, (double) minV);
        tessellator.addVertexWithUV((double) x, (double) y, (double) this.zLevel, (double) minU, (double) minV);
        tessellator.draw();
    }

    private void openUrl(String url) {
        try {
            Class<?> clazz = Class.forName("java.awt.Desktop");
            Object desktop = clazz.getMethod("getDesktop", new Class[0])
                .invoke(null, new Object[0]);
            clazz.getMethod("browse", URI.class)
                .invoke(desktop, new URI(url));
        } catch (Throwable throwable) {
            LOGGER.error("Couldn't open link", throwable);
        }
    }
}
