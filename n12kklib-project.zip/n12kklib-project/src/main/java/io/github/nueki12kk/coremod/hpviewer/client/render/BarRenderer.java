package io.github.nueki12kk.coremod.hpviewer.client.render;

import net.minecraft.client.renderer.Tessellator;

public class BarRenderer {

    public static void drawTexturedRect(float x, float y, float u, float v, int width, int height, float tileWidth,
        float tileHeight) {
        float invTexWidth = 1.0f / tileWidth;
        float invTexHeight = 1.0f / tileHeight;
        Tessellator tessellator = Tessellator.instance;
        tessellator.startDrawingQuads();
        tessellator.addVertexWithUV(x, y + height, 0.0, u * invTexWidth, (v + height) * invTexHeight);
        tessellator.addVertexWithUV(x + width, y + height, 0.0, (u + width) * invTexWidth, (v + height) * invTexHeight);
        tessellator.addVertexWithUV(x + width, y, 0.0, (u + width) * invTexWidth, v * invTexHeight);
        tessellator.addVertexWithUV(x, y, 0.0, u * invTexWidth, v * invTexHeight);
        tessellator.draw();
    }
}
